#include <vector>

using namespace std;

class Scheme
{
public:
	Scheme()
	{

	}

	~Scheme()
	{

	}

	vector<string> names;
};
