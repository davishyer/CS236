#include <vector>

using namespace std;

class Tuple : public vector<string>
{
public:
	Tuple()
	{

	}

	~Tuple()
	{

	}

	//vector<string> values;
};
