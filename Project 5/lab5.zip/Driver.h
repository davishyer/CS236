#include "Graph.h"

using namespace std;

class Driver
{
private:
public:
	Graph dependency;
	Driver()
	{

	}
	~Driver()
	{

	}
};
