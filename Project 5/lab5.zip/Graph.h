#include "Node.h"
#include <map>

using namespace std;

class Graph
{
private:
public:
	map<string, Node> graph;

	Graph()
	{

	}
	~Graph()
	{

	}
};
